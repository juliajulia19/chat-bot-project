import logging
import re

from aiogram import Bot, Dispatcher, executor, types
from aiogram.dispatcher import FSMContext
from aiogram.contrib.fsm_storage.files import JSONStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.types import ReplyKeyboardMarkup

from database_package import Appointments
from settings import API_TOKEN


# Configure logging

logging.basicConfig(level=logging.DEBUG)

# Initialize bot and dispatcher

storage = JSONStorage("storage.json")

bot = Bot(token=API_TOKEN)

dp = Dispatcher(bot, storage=storage)

class States(StatesGroup):
    main_state = State()
    first_aid_state = State()
    waiting_phone_state = State()
    waiting_day_state = State()
    waiting_time_state = State()

@dp.message_handler(commands=['start', 'help'], state="*")
async def send_welcome(message: types.Message, state: FSMContext):
    await States.main_state.set()
    async with state.proxy() as data:
        data['history'] = [message.text]
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("записать на приём", "удалить запись", "первая помощь")
    await message.reply("Здравствуйте! Я робот-администратор вет клиники Animal Planet.\nКак могу помочь?",
                        reply_markup=markup)
    logging.info(f"Message from {message.from_user.username}: {message.text}")

@dp.message_handler(regexp='.*(первая)\s?(помощь).*', state=States.main_state)
async def first_aid_start(message: types.Message, state: FSMContext):
    await States.first_aid_state.set()
    await message.answer('Если с вашим питомцем, что-то случилось и вы не знаете, что делать, '
                           'коротко опишите ситуацию и мы подскажем, как действовать.', reply_markup=types.ReplyKeyboardRemove())
    logging.info(f"Message from {message.from_user.username}: {message.text}")

@dp.message_handler(state=States.first_aid_state)
async def first_state(message: types.Message, state: FSMContext):
    if re.fullmatch(".*(отрав|рвота|рв[её]т|понос|тошн|диарея).*", message.text):
        await message.answer('вам нужно давать питомцу больше жидкости и абсорбент. Если не поможет,'
                             ' запишитесь на прием к нашему специалисту.')
    elif re.fullmatch(".*(слома|перелом).*", message.text):
        await message.answer('вам нужно зафиксировать конечность, наложить шину и срочно записаться на приём.')
    elif re.fullmatch(".*(хром|вывих|подверн).*", message.text):
        await message.answer('животному нужно больше лежать и дать покой поврежденной конечности. Если сильная боль, '
                             'опухоль, гематома, обратиться к врачу, чтобы исключить перелом или вывих, который требует вправления.')
    elif re.fullmatch(".*(подавил|поперхнул).*", message.text):
        await message.answer('попробуйте разжать пасть и достать предмет. Если это невозможно, запишитесь на прием.')
    elif re.fullmatch(".*(устал|пассивн|уста[её]т).*", message.text):
        await message.answer('вам нужно записаться на сдачу анализов, чтобы выявить причину недомогания')
    elif re.fullmatch(".*(высок|подним|поднял)(ая|ую|ается|ется|ась|)\s*(температур).*", message.text):
        await message.answer('если температура выше нормы, нужно дать жаропонижающее и записаться к врачу')
    elif re.fullmatch(".*(горяч)(ий|его)\s*(нос).*", message.text):
        await message.answer('нужно дать животному больше жидкости и измерить температуру')
    elif re.fullmatch(".*(ран(а|ы|ен)|порез).*", message.text):
        await message.answer('Всё зависит от глубины раны. Небольшие раны можно самостоятельнообработать перекесью и мазью левомиколь. '
                             'Более серьезные раны требуют консультации со специалистом')
    else:
        await message.answer('К сожалению информация по вашему запросу не включена в нашу базу знаний по первой помощи. '
                             'Пожалуйста запишитесь на приём для консультации')
    await States.main_state.set()
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("записать на приём", "удалить запись", "информация о моей записи", "первая помощь")
    await message.reply("Выберите нужное действие",
                        reply_markup=markup)
    logging.info(f"Message from {message.from_user.username}: {message.text}")

@dp.message_handler(regexp='.*(удалит|отменит)(ь|е)\s*(при[её]м|запись).*', state=States.main_state)
async def remove(message: types.Message, state: FSMContext):
    telegram_id = message.from_user.id
    Appointments.delete_user_by_telegram_id(telegram_id)
    await message.answer('Ваша запись удалена. Для перехода в основное меню нажмите /start', reply_markup=types.ReplyKeyboardRemove())
    await state.finish()
    logging.info(f"Message from {message.from_user.username}: {message.text}")


@dp.message_handler(regexp='.*((хочу|записаться)?)\s*((на)?)\s*(при[её]м).*', state=States.main_state)
async def phone(message: types.Message, state: FSMContext):
    await message.answer('Пожалуйста введите ваш номер телефона', reply_markup=types.ReplyKeyboardRemove())
    await States.waiting_phone_state.set()
    async with state.proxy() as data:
        data['history'] = [message.text]
    logging.info(f"Message from {message.from_user.username}: {message.text}")

@dp.message_handler(regexp='\+?[78]\s?\(?\d{3}\)?\s?([-\s]?\d[-\s]?){7}', state=States.waiting_phone_state)
async def day(message: types.Message, state: FSMContext):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("сегодня", "завтра", "послезавтра")
    await message.answer('Пожалуйста выберите день приёма', reply_markup=markup)
    await States.waiting_day_state.set()
    async with state.proxy() as data:
        data['phone'] = [message.text]
    logging.info(f"Message from {message.from_user.username}: {message.text}")


@dp.message_handler(regexp='.*(сегодня|завтра|послезавтра).*', state=States.waiting_day_state)
async def time(message: types.Message, state: FSMContext):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("10-00", "12-00", "15-00", '17-00')
    await States.waiting_time_state.set()
    async with state.proxy() as data:
        data['record_day'] = message.text
    await message.answer('Пожалуйста выберите время приёма', reply_markup=markup)
    logging.info(f"Message from {message.from_user.username}: {message.text}")

@dp.message_handler(regexp='.*(10-00|12-00|15-00|17-00).*', state=States.waiting_time_state)
async def confirmation(message: types.Message, state: FSMContext):
    telegram_id = message.from_user.id
    name = message.from_user.first_name
    async with state.proxy() as data:
        data['record_time'] = message.text
        day = data['record_day']
        Appointments.create(user_name=name, telegram_id=telegram_id, phone_number=data['phone'],
                            date=data['record_day'], time=data['record_time'])
    await message.answer(f'Спасибо! Я записал Вас на {day} на {message.text}. '
                         f'Чтобы вернуться в главное меню введите команду /start', reply_markup=types.ReplyKeyboardRemove())
    await state.finish()

    logging.info(f"Message from {message.from_user.username}: {message.text}")

@dp.message_handler(state="*")
async def unknown(message: types.Message, state: FSMContext):
    await message.answer('Нераспознанный запрос или вы ошиблись при вводе данных \n'
                         ' Попробуйте ещё раз или пожалуйста \n '
                         ' обратитесь по телефону 8-999-123-12-12. Для перехода в основное меню нажмите /start')
    logging.info(f"Message from {message.from_user.username}: {message.text}")


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)

