from peewee import PrimaryKeyField, TextField, IntegerField

from .db import BaseModel

class Appointments(BaseModel):
    user_id = PrimaryKeyField(null=False)
    user_name = TextField(null=False)
    telegram_id = IntegerField()
    phone_number = TextField()
    date = TextField()
    time = TextField()


    @staticmethod
    def from_telegram_id(tg_id):
        return Appointments.get(Appointments.telegram_id == tg_id)

    @staticmethod
    def delete_user_by_telegram_id(tg_id):
        Appointments.delete().where(Appointments.telegram_id == tg_id).execute()
