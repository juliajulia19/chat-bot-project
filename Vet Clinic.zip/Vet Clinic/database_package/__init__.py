from .db import BaseModel, database

from .table import Appointments

Appointments.create_table()